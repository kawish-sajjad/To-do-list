jQuery(document).ready(function($){
	$(".add-btn").on("click" , function(){
		var close_btn = $(".close-btn").val();
		var name = $(".to-do-list-input").val();
		if(name !== ''){
			$("ol").append('<li><span>' + $(".to-do-list-input").val() + '</span> <button class="delete-btn"><i class="fa fa-times delete"></i> </button> <button><i class="fa fa-pencil edit"></i></button></li>');
		}

		$(".to-do-list-input").val('');
	});

	 
	$(document).on("click", '.edit', function () {
    	$(this).closest("li").find("span").prop("contenteditable", true).focus();
  
  	});

	 $(document).on("click", '.delete', function () {
    	$(this).closest("li").fadeOut(function () {
      	$(this).remove();
    });

    });

});
